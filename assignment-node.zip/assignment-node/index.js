const express = require('express');
const axios = require('axios');
const fs = require('fs');
const csv = require('csv-parser');
const sqlite3 = require('sqlite3').verbose();

const app = express();
const port = 3000;

const db = new sqlite3.Database(':memory:');

db.serialize(() => {
    db.run("CREATE TABLE IF NOT EXISTS comments (postId INTEGER,id INTEGER,name TEXT,email TEXT,body TEXT)");
    db.run("CREATE TABLE IF NOT EXISTS csvdata (col1  TEXT,col2 TEXT,col3 TEXT)");
});

app.use(express.json());

app.get('/populate', async (req, res) => {
    try {

        const jsonResponse = await axios.get('https://jsonplaceholder.typicode.com/comments');
        const comments = jsonResponse.data;

        const stmt = db.prepare("INSERT INTO comments (postId, id,name,email,body) VALUES (?,?,?,?,?");
        comments.forEach(comment => {
            stmt.run(comment.postId,comment.id,comment.name,comment.email,comment.body);
        });
       stmt.finalize();

        const csvUrl = 'http://cfte.mbwebportal.com/deepak/csvdata.csv';
        const localCsvPath = './csvdata.csv';
        const writer = fs.createWriteStream(localCsvPath);
        const response = await axios.get(csvUrl, { responseType: 'stream'});
        response.data.pipe(writer);

        writer.on('finish', () => {
            fs.createReadStream(localCsvPath)
            .pipe(csv())
            .on('data',(row) => {
               const insertStmt = db.prepare("INSERT INTO csvdata (col1, col2, col3) VALUES (?,?,?)");
               insertStmt.run(row.col1,row.col2,row.col3);
               insertStmt.finalize();
            })
            .on('end',() => {
                res.send("Data fetched and stored successfully");
            });
        });

     writer.on('error',(err) => {
         res.status(500).send("Error saving CSV file");
     });

    } catch (error) {
        res.status(500).send("Error populating data");   
    }
});

app.post('/search',(req, res) => {
    const { name, email ,body, limit, sort } = req.body;
    let query = "SELECT *  FROM comments WHERE 1=1";

    if (name) query += `AND name LIKE '%${name}%' `; 
    if (email) query += `AND email LIKE '%${email}%' `; 
    if (body) query += `AND body LIKE '%${body}%' `; 

    if (sort) query += `ORDER BY ${sort.column}  ${sort.order}`; 
    if (limit) query += ` LIMIT ${limit} `; 
 
    db.all(query, [], (err, row) => {
        if (err) {
            res.status(500).send("Error fetching data");  
        } else {
            res.json(rows);
        }
    });
});


app.listen(port, () => {
    console.log(`Server is running  on http://localhost:${port}`);
});


